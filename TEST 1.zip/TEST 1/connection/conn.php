<?php
        $server = "localhost";
        $username = "root";
        $password = "";
      
    // Create connection/////////////////////////////////////////
           $conn = new mysqli($server, $username, $password );
       
           // Check connection
           if ($conn -> connect_error ) {
           die("Connection failed: " );
           } else{
       echo "Connection established";
           }
    //////////////////////////////////////////////////////////////
    
    // Create database//////////////////////////////////////////////
        $SQL_DATABASE = "CREATE DATABASE IF NOT EXISTS test";
        if ($conn->query($SQL_DATABASE) === TRUE) {
            echo "Database created successfully";
        } else {
            echo "Error creating database: " ;
        }
    ///////////////////////////////////////////////////////////////
    
       //CONNECTION AND SELECTIOON OF THE DATABASE AND CREATION OF TABLE IF EXISTS//
       $db_result = mysqli_select_db( $conn, 'test' );
       if(! $db_result ) {
          die('Could not select database: ');
   
       }else{
           echo"";
          
        echo "Database Test successfully selected <br />"; } 
?>