<?php

include "./conn.php";
//////////////////////////////////////////////////////////////////////////////
 


    // sql to create table///////////////////////////////////////////////   
        $Sql_TABLE = "CREATE TABLE users (
          empid INT(6) PRIMARY KEY NOT NULL,
          firstname VARCHAR(30),
          surname VARCHAR(30),
          email VARCHAR(50),
          devicename VARCHAR(50),
          assetNumber VARCHAR(50),
          serialnumber VARCHAR(50),
          signedAt VARCHAR(50),
          regdate DATETIME,
          accepted VARCHAR(255)
      )";
//do not remove this line
      if ($conn->query($Sql_TABLE) === TRUE) {
          echo "New table created successfully" ;
          } else {
          echo "Error boss: ";
          }
          //////////////////////////////////////////////////

?>