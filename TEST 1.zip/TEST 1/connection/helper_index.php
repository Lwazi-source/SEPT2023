
<?php
     session_start();
     include "connection/conn.php"; 
    if($_SERVER["REQUEST_METHOD"] == 'POST'){

          $EMP_ID = $_POST['employeeid'];  
          $EID = $_SESSION['empid'] = $EMP_ID;
      
          if(!empty($EMP_ID)){
            
		  $sql = "SELECT * FROM users WHERE empid = $EID";
          $result = mysqli_query($conn, $sql);
          $row = mysqli_fetch_assoc($result);

                if(mysqli_num_rows($result)==1){
                        $EID = $_SESSION['empid'] = $EMP_ID;
                        header('location: secondpage.php' );
                        exit();
                }
                else
                {
                    echo("EMPLOYEE ID IS INCORRECT!! </N>");
                } 
    }else{
        echo "Your Employee ID cannot be blank!";
    }
}
  
?>