<?php
    session_start();
    include "connection/conn.php"; 

    //This is to fetch data from database according to the session created.
     $sqll = "SELECT * FROM users WHERE empid = '{$_SESSION['empid']}'";
     $rizz = mysqli_query($conn, $sqll);
         if(mysqli_num_rows($rizz) > 0){
             if($row = mysqli_fetch_assoc($rizz)) {
            // echo '<input type="text" placeholder="NAME OF USER" name="name" value="'.htmlspecialchars($row['firstname']).'">';
             }
         }
       

            if(isset($_POST['submit'])){
        
                $accepted = $_POST['accepted']; 
                //This is to fetch data from database according to the session created. and also add the textbox whihc is accepted
                $sqlld = "UPDATE users SET accepted='accepted' WHERE empid = '{$_SESSION['empid']}'";
        
                    if ($conn->query($sqlld) === TRUE) {
                        echo "installed into table" ;
                        } else {
                        echo "Error boss: ";
                        }
                        // the message// this is the email
                           /* $msg = "First line of text\nSecond line of text";
                            // use wordwrap() if lines are longer than 70 characters
                            $msg = wordwrap($msg,70);

                            // send email
                            mail("lwazimabuza50@gmail.com","My subject",$msg);*/
                echo "send to email as confirmation";
                }
              //  echo '<input type="text" name="te" value="'.htmlspecialchars($accepted).'">';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="<KEY>" crossorigin="anonymous"></script>
    <title>ICT DEPARTMENT</title>

    <style>s
       li {padding-bottom: 2;}
       body{ font-family: Poppins;}
    </style>
</head>
<body class="p-3"> 
    <div class="container-fluid">
          <!--THIS IS A HEADER-->
                <nav class="navbar bg-body-tertiary p-3 ">
                    <div class="container bg-tertiary">
                        <!--fixed-top-->
                        <div class="row">
                            <div class="col">
                              <a class="navbar-brand" href="#">
                                <img src=" images/logo.png" alt="AVBOB" width="100" height="auto">
                            </a>    
                            </div>

                            <div class="col-sm-auto d-flex ">
                                    <h1>Acceptance of Liability and Undertaking of Security</h1>
                                </div>     
                    </div>
                </nav>
                <!--------->
    </div>
   
    <div class="container-sm ">
        <div class="card d-flex">
            <div class="section">

                <div class="title p-2">
                    <h2> ...</h2>
                </div>
                
                <div class="card-body bg-light p-5 ">
                <!--this is the body of the form which will be inside the card body.
                 all information should be in here.-->
                 <!-- THIS IS THE HEADER FOR THE FORM -->
                 <p>THIS IS A LIABILITY FORM FOR ACCEPTANCE THAT YOU ARE LIABLE FOR THE ASSET.</p>
                 <p>I, the undersigned, hereby accept liability for the computer device described here,
                     which has been placed under my supervision and control at all times.
                      I acknowledge and admit that I have agreed to the following conditions 
                      pertaining to the deployment and operation of the said device:</p>

                      <ol class="">
                        <li>
                            The device shall remain the property of AVBOB Mutual Assurance Society (hereinafter referred to as AVBOB) 
                            and must be returned to AVBOB without delay in the event where
                            I am instructed to return same or if my employment with AVBOB
                            is terminated for any reason whatsoever;
                  
                        </li>

                        <li>
                            I accept that the device is allocated to me exclusively
                            and only for official/business purposes and that it may 
                            not be used for any private purpose whatsoever without 
                            the express written permission of the Chief Information Officer;

                        </li>

                        <li> 
                            I accept that I may only use accessories (including but not limited to 
                            computer software) which are approved by AVBOB and I shall not, under any circumstances,
                            be allowed to install or insert any accessory without the express written permission of 
                            the Manager: Systems / Datacenter nor shall I delete, obliterate or remove any accessory 
                            which was approved and installed by AVBOB;
                        </li>

                        <li>
                            AVBOB shall ensure that the device and any accessories (including but not 
                            limited to computer software) required for normal operation thereof are legally 
                            obtained and registered and insured against damage or theft;
                        </li>

                        <li class="p-2">
                            I accept the responsibility and shall take every reasonable precaution
                            to secure and protect the device against theft or damage at all times 
                            and agree that it shall remain my responsibility to report the theft of 
                            the device to the nearest Police station as well as to provide the Chief 
                            Information Officer with the respective case number;

                        </li>

                        <li class="p-2">
                            I accept that I shall be liable for the excess payment of
                            R 5 000 (Five Thousand Rand) or 10% of the total cost of the 
                            laptop, whichever is the greater, in the event that the device is lost,
                            stolen or damaged parts or beyond repair, as a result of negligence on
                            my part and that such amount may be deducted from my remuneration in terms
                                sec 34(2) of the Basic Conditions of Employment Act as amended; 
                        </li>

                        <li class="p-2">
                            I accept responsibility and shall take every reasonable precaution to
                            maintain the confidentiality and integrity of all electronic information
                            and/or data to which I may have access via AVBOB’s computer network and
                    
                        </li>

                        <li class="p-2">
                            I accept responsibility and shall take every reasonable precaution 
                            to ensure that no information/data I shall have access to is made
                            available to any third party (in whatever form) without the express
                            written permission of the Chief Information Officer.

                        </li>

                      </ol>

                      <form action="secondpage.php" method="POST" class="" name="">
                        <div class="form-control p-3 text-center w-100 ">
                            <div class="row m-auto">
                                <div class="container-fluid mb-3  ">
                                    <input type="email"  class="form-control" name="EMAIL_ADDRESS" placeholder="EMAIL ADDRESS" id="" value="<?php echo $row['email'];?>" readonly>
                                </div>

                                    <div class="container-fluid mb-3">
                                        <?php 
                                        $EID = $_SESSION['empid'];
                                        if(isset($EID)){
                                            echo '<input type="number" class="form-control" placeholder="EMPLOYEE ID" name="employeeid" value="'.htmlspecialchars($EID).'" readonly>';
                                        }else{
                                            echo "xxxx";
                                        }?>
                                        </div>
                                </div>
                        <!---------------------------------------------------------------->
                        <div class="container-fluid mb-3">
                            <input class="form-control" type="text" placeholder="NAME OF USER" name="name" value="<?php echo $row['firstname']; ?>" readonly>
                        </div>
                        <!--surname of user-->
                        <div class="container-fluid mb-3">
                            <input type="text"  class="form-control" placeholder="SURNAME OF USER" name="surname" id="" value="<?php echo $row['surname']; ?>" readonly>
                        </div>

                        <!--device name of laptop-->
                          <div class="container-fluid mb-3">
                            <input type="text"  class="form-control" placeholder="dEVICE DESCRIPTION" name="devdesc" id="" value="<?php echo $row['devicename'];?>" readonly>
                        </div>
                        <!--device asset number; eg:093000923-->
                        <!---------------------------------------------------------------->
                        <div class="container-fluid mb-3">
                            <input type="number"  class="form-control" placeholder="DEVICE ASSET NUMBER" name="devassno" id="" value="<?php echo $row['assetNumber'];?>" readonly>
                        </div>
                        <!---------------------------------------------------------------->
                        <div class="container-fluid mb-3">
                            <input type="text"  class="form-control" placeholder="DEVICE SERIAL NUMBER" name="SERIAL_NUMBER" id="" value="<?php echo $row['serialnumber'];?>" readonly>
                        </div>
                        <!--date of competion of user-->
                        <div class="container-fluid mb-3">
                            <input type="date" class="form-control" placeholder="DATE OF COMPLETION"name="DATE" id="" value="<?php echo $row['regdate'];?>">
                        </div>
                        <!---------------------------------------------------------------->
                        <div class="container-fluid mb-3 h-auto">
                            <input class="form-control" type="text" placeholder="SIGNED AT THIS LOCATION" name="LOCATION" id="" value="<?php echo $row['signedAt'];?>" readonly>
                        </div>
                   
                        <div class="container-fluid  ">
                        <div class="input-group text-center ">
                            <div class="input-group-text mx-auto ">
                                <input class="form-check-input" name="accepted" type="checkbox" value="<?php echo $row['accepted'];?>" >
                            <label for=""> I hereby accept that I am Liable to all the above mentioned </label></br>

                        </div>
                    </div>
                </div>
                    <p></p>
                        <div class="container mx-auto">
                            <button type="submit" class="btn btn-success" name="submit">Submit information</button>
                        </div>
                        
                   
                    </div>
                </form>
                  
                </div>

            </div>
           
        </div>
    </div>

    
</body>
</html>

<!---------------------------------------------------------------->
<?php   

    include "connection/conn.php"; 
//
$EID = $_SESSION['empid'];
  
if(isset($EID)){
    echo '<input type="text" name="employeeid" value="'.htmlspecialchars($EID).'">';
 
}else{
    echo "xxxx";
}

            
?>
<!---->