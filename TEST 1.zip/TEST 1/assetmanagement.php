<?php
  require "connection/conn.php";
     

  $sql = "SELECT * FROM users";
  $result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="<KEY>" crossorigin="anonymous"></script>
    <title>ICT DEPARTMENT</title>
    <style>
       li {padding-bottom: 2;}
       body{ font-family: Poppins;}
    </style>
</head>
<body>
    <div class="container-fluid">
          <!--THIS IS A HEADER-->
                <nav class="navbar bg-body-tertiary p-3 ">
                    <div class="container bg-tertiary">
                        <!--fixed-top-->
                        <div class="row">
                            <div class="col">
                              <a class="navbar-brand" href="#">
                                <img src=" images/AVBOB.jfif" alt="AVBOB" width="100" height="auto">
                            </a>    
                        </div>
                        <div class="col-sm-auto d-flex ">
                            <h1>Acceptance of Liability and Undertaking of Security</h1>
                        </div>     
                    </div>
                </nav>
            </div>

<div class="container-sm ">
        <div class="card d-flex">
            <div class="section">

                <div class="title p-2">
                    <h2> EDIT USERS INFORMATION</h2>
                </div>
                
                <div class="card-body bg-light p-5 ">
                    <?php
                        if(mysqli_num_rows($result) > 0){
                            echo "<table class=table table-light p-2>";

                            echo "<tr class=table-active>
                            <th>EMPLOYEE ID</th>
                            <th>EMPLOYEE NAME</th>
                            <th>EMPLOYEE SURNAME</th>
                            <th>EMPLOYEE EMAIL</th>
                            <th>EMPLOYEE DEVICE</th>
                            <th>EMPLOYEE ASSET NUMBER</th>
                            <th>EMPLOYEE SERIAL NUMBER</th>
                            <th>EMPLOYEE ACCEPTANCE</th>
                            </tr>";

                            while($row = mysqli_fetch_assoc($result)){
                                echo "<tr>";
                                echo "<td>" .$row['empid']. "</td>";
                                echo "<td>".$row['firstname']. "</td>";
                                echo "<td>".$row['surname']. "</td>";
                                echo "<td>".$row['email']. "</td>";
                                echo "<td>".$row['devicename']. "</td>";
                                echo "<td>".$row['assetNumber']. "</td>";
                                echo "<td>".$row['serialnumber']. "</td>";
                                echo "<td>".$row['accepted']. "</td>";
                                echo '<td> <button type="submit" class="btn btn-danger w-100" name="delete">Delete</button></td>';
                                echo '<td> <button type="submit" class="btn btn-primary w-100" name="update">Update</button></td>';
                                echo "</tr>";
                            }
                            echo "</table>";
                        }else{
                            echo "0 results from database";
                        }
                    ?>
                </div>
                

                <form action="assetmanagement.php" method="POST" class="" name="">
                        <div class="form-control p-3 text-left">
                            <table>
                                <tr>
                                    <td>
                                        <input type="text" class="form-control" placeholder="EMPLOYEE ID"  id="employeeid" name="employeeid">
                                    </td>

                                    <td>
                                        <input class="form-control" type="text" placeholder="NAME OF USER" name="name" >
                                    </td>

                                    <td>
                                        <input type="text" class="form-control" placeholder="SURNAME OF USER" name="surname" id="" >
                                    </td>

                                    <td>
                                        <input class="form-control" type="email" name="EMAIL_ADDRESS" placeholder="EMAIL ADDRESS" id="" class="" >
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td>
                                        <input type="text" class="form-control"  placeholder="dEVICE DESCRIPTION" name="devdesc" id="" >
                                    </td>

                                    <td>
                                        <input type="number" class="form-control"  placeholder="DEVICE ASSET NUMBER" name="devassno" id="" >
                                    </td>

                                    <td>
                                        <input type="text"  class="form-control"  placeholder="DEVICE SERIAL NUMBER" name="SERIAL_NUMBER" id="" >
                                    </td>

                                     <td>
                                        <input type="date"  class="form-control"  placeholder="DATE OF COMPLETION"name="DATE" id="" >
                                    </td>
                                </tr>

                                <tr>
                                    
                                    <td>
                                        <input type="text"  class="form-control" placeholder="SIGNED AT THIS LOCATION" name="LOCATION" id="" >
                                    </td>

                                    <td>
                                        <button type="submit" class="btn btn-primary w-100" name="update">Update</button>
                                    </td>

                                  

                                    <td>
                                        <button type="submit" class="btn btn-danger w-100" name="delete">Delete</button>
                                    </td>
                                    <!-- add new user to table-->
                                    <td>
                                         <button type="submit" class="btn btn-success w-100" name="add">Add</button>
                                    </td>
                                </tr> 
                            </table>
                        </div>
                    </form>

                <?php 
                if(isset($_POST['add'])){
                    $EMP_ID = $_POST['employeeid']; 
                    $NAME_OF_U = $_POST['name']; 
                    $SURNAME = $_POST['surname']; 
                    $EMAIL = $_POST['EMAIL_ADDRESS'];
                    $DEVICE_DESC = $_POST['devdesc'];
                    $DEV_ASSET_NO = $_POST['devassno'];
                    $SERIAL_NO = $_POST['SERIAL_NUMBER'];
                    $DATE = $_POST['DATE'];
                    $LOC = $_POST['LOCATION'];

                    $sql = "INSERT INTO users (empid, firstname, surname, email, devicename, assetnumber, serialnumber, regdate, signedAt)
                                    VALUES ('".$EMP_ID."' , '".$NAME_OF_U."' , '".$SURNAME."' , '".$EMAIL."' , '".$DEVICE_DESC."' , '".$DEV_ASSET_NO."' , '".$SERIAL_NO."' , '".$DATE."' , '".$LOC."')";
                                    
                                    if ($conn->query($sql) === TRUE) {
                                         echo "New record created successfully" ;
                                         } else {
                                            echo "Error boss: ";
                                        }
                                    }
                                    ////////delete
                                    if(isset($_POST['delete'])){
                                        $EMP_ID = $_POST['employeeid']; 
                                        $NAME_OF_U = $_POST['name']; 
                                        $SURNAME = $_POST['surname']; 
                                        $EMAIL = $_POST['EMAIL_ADDRESS'];
                                        $DEVICE_DESC = $_POST['devdesc'];
                                        $DEV_ASSET_NO = $_POST['devassno'];
                                        $SERIAL_NO = $_POST['SERIAL_NUMBER'];
                                        $DATE = $_POST['DATE'];
                                        $LOC = $_POST['LOCATION'];
                    
                                        $sql = "INSERT INTO users (empid, firstname, surname, email, devicename, assetnumber, serialnumber, regdate, signedAt)
                                                        VALUES ('".$EMP_ID."' , '".$NAME_OF_U."' , '".$SURNAME."' , '".$EMAIL."' , '".$DEVICE_DESC."' , '".$DEV_ASSET_NO."' , '".$SERIAL_NO."' , '".$DATE."' , '".$LOC."')";
                                                        
                                                        if ($conn->query($sql) === TRUE) {
                                                             echo "New record created successfully" ;
                                                             } else {
                                                                echo "Error boss: ";
                                                            }
                                                        }

              
    

    ///////////////////INSERT INTO TABLE///////////////////////////////
              /*   <?php  echo '<input type="text" name="accepted" value="'.htmlspecialchars($accepted).'">';?>*/
               
            
                ?>
            </div>
</body>
</html>
           