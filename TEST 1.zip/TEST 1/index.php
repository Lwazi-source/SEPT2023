<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="<KEY>" crossorigin="anonymous"></script>
    <title>ICT DEPARTMENT</title>

    <style>
       li {padding-bottom: 2;}
       body{ font-family: Poppins;}
    </style>
</head>
<body class="p-3"> 
    <div class="container-fluid">
          <!--THIS IS A HEADER-->
                <nav class="navbar bg-body-tertiary p-3 ">
                    <div class="container bg-tertiary">
                        <!--fixed-top-->
                        <div class="row">
                            <div class="col">
                              <a class="navbar-brand" href="#">
                                <img src=" images/AVBOB.jfif" alt="AVBOB" width="100" height="auto">
                            </a>    
                            </div>

                            <div class="col-sm-auto d-flex ">
                                    <h1>Acceptance of Liability and Undertaking of Security</h1>
                                </div>     
                    </div>
                </nav>
                <!--------->
    </div>
   
    <div class="container-sm ">
        <div class="card d-flex">
            <div class="section">

                <div class="title p-2">
                    <h2> ...</h2>
                </div>
           

                 <div class="card-body bg-light p-5 ">

                <form action="index.php" method="POST" class="" name="">
                      <div class="form-control p-3 text-center ">
                        <!---------------------------------------------------------------->
                        <div class="row m-auto">
                             <div class=" mb-3">
                                <label for="employeeid" class="col-sm col-form-label">PLEASE ENTER YOUR EMPLOYEE NUMBER.</label></br>
                            <input type="number"  class="form-control" placeholder="EMPLOYEE ID" name="employeeid" id="" value="<?php echo '.$EMP_ID.'?>">
                        </div>
                    </div>

                        <div class="container align-right">
                        <button type="submit" class="btn btn-success" name="submit">Submit</button>
                        </div>
                    </div>
<?php
include "connection/helper_index.php";
?>

<!---->
                </form>
                  
                </div>

                    <form action="assetpage.php" method="POST">
                        <div class="form-control p-3 text-left ">
                            <div class="row">
                                <div class=" mb-3">
                                    <label for="" class="col-sm col-form-label">Only for the asset manager use. Add a user and assign 
                                        information to them like a new pc etc using their information.
                                    </label></br>
                                    <button type="submit" class="btn btn-danger" name="submitA">Add New User & Laptop</button>
                            </div>
                        </div>
                    </form>

            </div>
            
        </div>
    </div>
   
    
</body>
</html>
<!-- Copyright-->
