<?php

session_start();
        $server = "localhost";
        $username = "root";
        $password = "";
      
    // Create connection/////////////////////////////////////////
           $conn = new mysqli($server, $username, $password );
       
           
       //CONNECTION AND SELECTIOON OF THE DATABASE AND CREATION OF TABLE IF EXISTS//
       $db_result = mysqli_select_db( $conn, 'test' );
       if(! $db_result ) {
          die('Could not select database: ');
   
       }else{
           echo"";
          
        echo "Database Test successfully selected <br />"; } 

    // sql to create table///////////////////////////////////////////////   
        $Sql_TABLE = "CREATE TABLE IF NOT EXISTS assetmanager (
            id INT(6) NOT NULL PRIMARY KEY,
            email VARCHAR(50),
            pass VARCHAR(50)
        );";
  //do not remove this line

       if (  mysqli_query($conn, $Sql_TABLE) === TRUE) {
            echo "New table created successfully" ;
            } else {
            echo "Error boss: ";
            }

            //////////////////////////////////////////////////
  
            if(isset($_POST['submit'])){
               $_SESSION = $email = $_POST['email'];
                $pass = $_POST['pass'];
               
                $sql = "SELECT * FROM assetmanager WHERE email = '$email' AND pass = '$pass'";
                
                $result = $conn -> query($sql);
                
                if(mysqli_num_rows($result)==1){
                    $row = mysqli_fetch_assoc($result);
                    echo "yeah boi";
                    header('location: assetmanagement.php' );
                    exit();
            }else{
                echo "nope boi";
            }
        }
         
     

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="<KEY>" crossorigin="anonymous"></script>
    <title>ICT DEPARTMENT</title>
</head>
<body>
    <div class="container-fluid">
          <!--THIS IS A HEADER-->
                <nav class="navbar bg-body-tertiary p-3 ">
                    <div class="container bg-tertiary">
                        <!--fixed-top-->
                        <div class="row">
                            <div class="col">
                              <a class="navbar-brand" href="#">
                                <img src=" images/AVBOB.jfif" alt="AVBOB" width="100" height="auto">
                            </a>    
                        </div>
                        <div class="col-sm-auto d-flex ">
                            <h1>Acceptance of Liability and Undertaking of Security</h1>
                        </div>     
                    </div>
                </nav>
            </div>

<div class="container-sm ">
        <div class="card d-flex">
            <div class="section">

                <div class="title p-2">
                    <h2> ASSET MANAGEMENT CONSOLE</h2>
                </div>
                
                <div class="card-body bg-light p-5 ">
        
                      <form action="assetpage.php" method="POST" class="" name="">
                        <div class="form-control p-3 text-center w-100 ">
                            <div class="row m-auto">
                                <div class="container-fluid mb-3  ">
                                    <input type="email"  class="form-control" name="email" placeholder="ENTER EMAIL ADDRESS" id="" value="" >
                                </div>
                        <!---------------------------------------------------------------->
                        <!--surname of user-->
                        <div class="container-fluid mb-3">
                            <input type="password"  class="form-control" placeholder="Enter Password" name="pass" id="" value="" >
                        </div>

                        <div class="container mx-auto">
                            <button type="submit" class="btn btn-danger w-50" name="submit">Login</button>
                        </div>
                        
                   
                    </div>
                </form>
                  
                </div>

            </div>
</body>
</html>
           